package com.clubdeportivo.serviciocanchas.client;

import java.util.Collections;
import java.util.List;

import org.springframework.stereotype.Component;

import com.clubdeportivo.serviciocanchas.model.Reserva;

@Component
public class ReservaClientFallback implements ReservaClient {

    @Override
    public List<Reserva> obtenerReservasPorCancha(Long canchaId) {
        // Servicio de reservas no disponible; devolvemos lista vacía para no abrir excepción
        return Collections.emptyList();
    }
}
