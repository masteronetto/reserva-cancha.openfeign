package com.clubdeportivo.serviciocanchas.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.clubdeportivo.serviciocanchas.model.Reserva;

@FeignClient(name = "reservas-service", url = "${reservas.service.url}", fallback = ReservaClientFallback.class)
public interface ReservaClient {

    @GetMapping("/api/reservas/cancha/{canchaId}")
    List<Reserva> obtenerReservasPorCancha(@PathVariable("canchaId") Long canchaId);

}
