package com.clubdeportivo.serviciocanchas.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Reserva {

    private Long id;
    private Long canchaId;
    private String fecha;
    private String horaInicio;
    private String horaFin;
    private String cliente;

}
