package com.clubdeportivo.serviciocanchas.services;
import java.util.List;
import com.clubdeportivo.serviciocanchas.model.Cancha;
import com.clubdeportivo.serviciocanchas.model.Reserva;

public interface CanchaServices {

    List<Cancha> listarCanchas();

    Cancha crearCancha(Cancha cancha);
    
    Cancha buscarCancha(Long id);

    List<Reserva> obtenerReservasPorCancha(Long canchaId);

}
