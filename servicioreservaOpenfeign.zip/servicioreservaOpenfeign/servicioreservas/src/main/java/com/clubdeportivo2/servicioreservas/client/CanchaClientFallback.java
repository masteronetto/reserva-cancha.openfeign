package com.clubdeportivo2.servicioreservas.client;

import java.util.Collections;
import java.util.List;

import org.springframework.stereotype.Component;

import com.clubdeportivo2.servicioreservas.model.dto.Cancha;

@Component
public class CanchaClientFallback implements CanchaClient {

    @Override
    public Cancha obtenerCancha(Long id) {
        // Servicio de canchas no disponible; devolvemos null para manejarlo en servicio
        return null;
    }

    @Override
    public List<Cancha> listarCanchas() {
        // Servicio de canchas no disponible; devolvemos lista vacía para no romper llamadas
        return Collections.emptyList();
    }
}
