package com.clubdeportivo2.servicioreservas.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.clubdeportivo2.servicioreservas.model.dto.Cancha;

@FeignClient(name = "canchas-service", url = "${canchas.service.url}", fallback = CanchaClientFallback.class)
public interface CanchaClient {

    @GetMapping("/api/canchas/{id}")
    Cancha obtenerCancha(@PathVariable("id") Long id);

    @GetMapping("/api/canchas")
    List<Cancha> listarCanchas();
}
